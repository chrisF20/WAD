﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace IdentityProject.Models
{
    public class CartItem
    {
        public int FightID { get; set; }

        public string FightTitle { get; set; }

        public int OrderQuantity { get; set; }

        public decimal FightPrice { get; set; }

        public DateTime OrderDate { get; set; }
    }
}
