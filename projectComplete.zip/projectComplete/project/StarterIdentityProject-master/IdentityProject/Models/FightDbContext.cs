﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace IdentityProject.Models
{
    public class FightDbContext: DbContext
    {
        public FightDbContext(DbContextOptions<FightDbContext> options)
           : base(options)
        {
        }

        public DbSet<Events> Venues { get; set; }

        public DbSet<Fighters> Athletes { get; set; }
    }
}
