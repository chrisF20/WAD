# Starter ASP.NET Core MVC Project for Working with Identity

