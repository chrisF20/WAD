﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
//using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Logging;
using IdentityProject.Models;
using Microsoft.AspNetCore.Http;
using PagedList;

namespace IdentityProject.Controllers
{

    public class HomeController : Controller
    {

        private readonly ILogger<HomeController> _logger;

        private readonly ApplicationDbContext _context;

        private readonly FightDbContext _FEvents;

        const string SessionCart = "_Cart";

        public HomeController(ILogger<HomeController> logger, ApplicationDbContext context, FightDbContext fEvents)
        {
            _context = context;
            _logger = logger;
            _FEvents = fEvents;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult testing()
        {
            return View();
        }

        public IActionResult AllCars()
        {
            List<AllCars> model = _context.AllCarsShow.ToList();
                
            return View(model);
        }

        public IActionResult AllFilms(string sortOrder)
        {
            ViewBag.DateSortParam = sortOrder == "Date" ? "date_desc" : "Date";
            var events = from s in _FEvents.Venues
                         select s;
            switch (sortOrder)
            {
                case "Date":
                    events = events.OrderBy(s => s.FightTime);
                    break;

                case "date_desc":
                    events = events.OrderByDescending(s => s.FightTime);
                    break;

                default:
                    events = events.OrderBy(s => s.FightTitle);
                    break;
            }
            return View(events.ToList());

            List < Film > model = _context.Films.ToList();
            return View(model);
        }

        public ActionResult AllEvents()
        {
            List<Events> model = _FEvents.Venues.ToList();
            return View(model);
            }

        public ActionResult filtertest(string sortOrder, string currentFilter, string searchString, int? page)
        {
            ViewBag.CurrentSort = sortOrder;
            ViewBag.NameSortParm = String.IsNullOrEmpty(sortOrder) ? "title_desc" : "";
            ViewBag.DateSortParm = sortOrder == "Date" ? "date_desc" : "Date";

            if (searchString != null)
            {
                page = 1;
            }
            else
            {
                searchString = currentFilter;
            }

            ViewBag.CurrentFilter = searchString;

            var events = from s in _FEvents.Venues
                         select s;
            if (!String.IsNullOrEmpty(searchString))
            {
                events = events.Where(s => s.FightTitle.Contains(searchString)
                                       || s.FightVenue.Contains(searchString));
            }
            switch (sortOrder)
            {
                case "name_desc":
                    events = events.OrderByDescending(s => s.FightTitle);
                    break;
                case "Date":
                    events = events.OrderBy(s => s.FightTime);
                    break;
                case "date_desc":
                    events = events.OrderByDescending(s => s.FightTime);
                    break;
                default:  // Name ascending 
                    events = events.OrderBy(s => s.FightTitle);
                    break;
            }

            int pageSize = 3;
            int pageNumber = (page ?? 1);
            return View(events.ToPagedList(pageNumber, pageSize));
            //List<Events> model = _FEvents.Venues.ToList();
            //return View(model.ToPagedList(pageNumber, pageSize));

            // return View(events.ToList());
        }

        public IActionResult AllFighters()
        {
            List<Fighters> model = _FEvents.Athletes.ToList();
            return View(model);
        }

        public IActionResult Search(String SearchString, String Location)
        {

            var events = from m in _FEvents.Venues

                        select m;

            if (!string.IsNullOrEmpty(SearchString))

            {

                events = events.Where(s => s.FightTitle.Contains(SearchString));

            }

            if (!string.IsNullOrEmpty(Location))
            {
                events = events.Where(x => x.FightVenue.Contains(Location));
            }

            var EventLocation = _FEvents.Venues.Select(m => m.FightVenue).Distinct();


            List<Events> model = events.ToList();
            ViewData["SearchString"] = SearchString;
            ViewData["FilterEventLocation"] = Location;
           // ViewData["EventLocation"] = Location.ToList();
            //ViewData["EventLocationSelectList"] = new SelectList(EventLocation.ToList());
            return View(model);
        }


        // note uses id because of routing in startup.cs
        [HttpGet]
        public IActionResult FilmDetails(int id)
        {
            //List<Film> model = _context.Films.Find(FilmID);
            Film model = _context.Films.Find(id);
            return View(model);
        }

        public IActionResult CarDetails(int id)
        {
            //List<Film> model = _context.Films.Find(FilmID);
            AllCars model = _context.AllCarsShow.Find(id);
            return View(model);
        }

        public IActionResult FightDetails(int id)
        {
            //List<Film> model = _context.Films.Find(FilmID);
            Events model = _FEvents.Venues.Find(id);
            return View(model);
        }

        public IActionResult FighterDetails(int id)
        {
            //List<Film> model = _context.Films.Find(FilmID);
            Fighters model = _FEvents.Athletes.Find(id);
            return View(model);
        }



        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        [HttpPost]
        public IActionResult FightDetails(IFormCollection form)

        {

            int FightID = int.Parse(form["FightID"]);
            string FightTitle = form["FightTitle"].ToString();
            decimal FightPrice = Decimal.Parse(form["FightPrice"]);
            int OrderQuantity = int.Parse(form["OrderQuantity"]);
            CartItem newOrder = new CartItem();
            newOrder.FightID = FightID;
            newOrder.FightTitle = FightTitle;
            newOrder.FightPrice = FightPrice;
            newOrder.OrderQuantity = OrderQuantity;
            newOrder.OrderDate = DateTime.Now;

            var CartList = new List<CartItem>();

            if (HttpContext.Session.GetString(SessionCart) != null)
            {
                string serialJSON = HttpContext.Session.GetString(SessionCart);
                CartList = JsonSerializer.Deserialize<List<CartItem>>(serialJSON);
                //
                var item = CartList.FirstOrDefault(o => o.FightID == FightID);
                if (item != null)
                {
                    item.OrderQuantity += OrderQuantity;
                }
                else
                {
                    CartList.Add(newOrder);
                }

            }
            else
            {
                CartList.Add(newOrder);
            }
            HttpContext.Session.SetString(SessionCart, JsonSerializer.Serialize(CartList));
            return RedirectToAction("FightDetails");

        }

        

        [HttpGet]
        public IActionResult ManageCart()

        {
            List<CartItem> cart = new List<CartItem>();
            if (HttpContext.Session.GetString(SessionCart) != null)
            {
                string serialJSON = HttpContext.Session.GetString(SessionCart);
                cart = JsonSerializer.Deserialize<List<CartItem>>(serialJSON);
            }
            if (TempData["msg"] != null)
            {
                ViewBag.msg = TempData["msg"].ToString();
            }
            return View(cart);

        }

        [HttpPost]
        public IActionResult RemoveCartItem(IFormCollection form)
        {
            int FightID = int.Parse(form["FightID"]);
            var CartList = new List<CartItem>();
            if (HttpContext.Session.GetString(SessionCart) != null)
            {
                string serialJSON = HttpContext.Session.GetString(SessionCart);
                CartList = JsonSerializer.Deserialize<List<CartItem>>(serialJSON);
                var item = CartList.FirstOrDefault(o => o.FightID == FightID);
                if (item != null)
                {
                    CartList.Remove(item);
                }

            }

            HttpContext.Session.SetString(SessionCart, JsonSerializer.Serialize(CartList));
            TempData["msg"] = "Item Removed";
            return RedirectToAction("ManageCart");
        }

        

        public IActionResult Checkout()

        {
            return View();

        }
    }
}
