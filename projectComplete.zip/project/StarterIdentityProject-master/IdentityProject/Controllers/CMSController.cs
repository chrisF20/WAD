﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using IdentityProject.Models;
using System.IO;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Authorization;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace IdentityProject.Controllers
{
    [Authorize(Roles = "Manager")]
    public class CMSController : Controller
    {
        private readonly ILogger<CMSController> _logger;

        private readonly ApplicationDbContext _context;

        private readonly FightDbContext _Fightcontext;

        private readonly IWebHostEnvironment _webHostEnvironment;

        public CMSController(ILogger<CMSController> logger, ApplicationDbContext context, FightDbContext Fightcontext, IWebHostEnvironment hostEnvironment)
        {
            _context = context;
            _logger = logger;
            _Fightcontext = Fightcontext;
            _webHostEnvironment = hostEnvironment;
        }

        // GET: /<controller>/
        public IActionResult Index()
        {
            List<Events> model = _Fightcontext.Venues.ToList();
            //List<Events> modell = _Fightcontext.Athletes.ToList();
            return View(model);
        }

        public IActionResult Index2()
        { 
            List<Fighters> modell = _Fightcontext.Athletes.ToList();
            return View(modell);
        }

        [HttpGet]
        public IActionResult AddFighter()
        {
            return View();
        }

        [HttpPost]
        public IActionResult AddFighter(FighterForm model)
        {


            if (ModelState.IsValid)
            {

                Fighters newFighters = new Fighters
                {

                    FirstName = model.FirstName,
                    LastName = model.LastName,
                    NickName = model.NickName,
                    Height = model.Height,
                    Weight = model.Weight,
                    Reach = model.Reach,
                    Stance = model.Stance,
                    Wins = model.Wins,
                    Loss = model.Loss,
                    Draw = model.Draw,
                    Belt = model.Belt,

                };
                _Fightcontext.Add(newFighters);
                _Fightcontext.SaveChanges();
                return RedirectToAction(nameof(Index));
            }

            return View();

        }

        [HttpGet]
        public IActionResult AddFilm()
        {
            return View();
        }

        [HttpPost]
        public IActionResult AddFilm(EventForm model)
        {
            
            if (ModelState.IsValid)
            {
                //string uniqueFileName = UploadedFile(model);
                var tuple = UploadedFile(model);
                string uniqueFileName = tuple.Item1;
                string fileExt = tuple.Item2;
                long fileSize = tuple.Item3;
                string[] permittedExtensions = { ".gif", ".jpg", ".jpeg", ".png" };

                // 5 MB
                if (fileSize > 5000000)
                {
                    ViewBag.msg = "Image Too Big: " + fileSize.ToString();

                    return View();
                }
                if (!permittedExtensions.Contains(fileExt))
                {
                    ViewBag.msg = "Wrong File type " + fileExt;
                    return View();
                }

                Events newEvents = new Events
                {
                    FightTitle = model.FightTitle,
                    FightVenue = model.FightVenue,
                    FightImage = uniqueFileName,
                    Fighters = model.Fighters,
                    FightPrice = model.FightPrice,
                    FightTime = model.FightTime,

                };
                _Fightcontext.Add(newEvents);
                _Fightcontext.SaveChanges();
                return RedirectToAction(nameof(Index));
            }

            return View();

        }

        private Tuple<string, string, long> UploadedFile(EventForm model)
        {
            string uniqueFileName = null;
            string fileExtension = null;
            long fileSize = 0;

            if (model.FightImage != null)
            {
                string uploadsFolder = Path.Combine(_webHostEnvironment.WebRootPath, "images");
                //uniqueFileName = Guid.NewGuid().ToString() + "_" + model.FilmImage.FileName;
                fileExtension = Path.GetExtension(model.FightImage.FileName);
                fileExtension = fileExtension.ToLowerInvariant();
                uniqueFileName = Guid.NewGuid().ToString() + fileExtension;
                //uniqueFileName = "test";
                string filePath = Path.Combine(uploadsFolder, uniqueFileName);
                using (var fileStream = new FileStream(filePath, FileMode.Create))
                {
                    model.FightImage.CopyTo(fileStream);
                    fileSize = fileStream.Length;
                }
            }
            return new Tuple<string, string, long>(uniqueFileName, fileExtension, fileSize);
        }


        // note uses id because of routing in startup.cs
        [HttpGet]
        public IActionResult UpdateFilm(int id)
        {
            //List<Film> model = _context.Films.Find(Id);
            Events model = _Fightcontext.Venues.Find(id);
            EventForm formModel = new EventForm
            {
                FightTitle = model.FightTitle,
                FightVenue = model.FightVenue,
                Fighters = model.Fighters,
                FightPrice = model.FightPrice,
                FightTime = model.FightTime,

            };
            ViewBag.ImageName = model.FightImage;
            return View(formModel);
        }

        [HttpPost]
        public IActionResult UpdateFilm(EventForm model)
        {
            if (model.FightImage != null)
            {
                var tuple = UploadedFile(model);
                string uniqueFileName = tuple.Item1;
                string fileExt = tuple.Item2;
                long fileSize = tuple.Item3;
                string[] permittedExtensions = { ".gif", ".jpg", ".jpeg", ".png" };

                // 5 MB
                if (fileSize > 5000000)
                {
                    ViewBag.msg = "Image Too Big: " + fileSize.ToString();

                    return View();
                }
                if (!permittedExtensions.Contains(fileExt))
                {
                    ViewBag.msg = "Wrong File type " + fileExt;
                    return View();
                }

                Events editEvents = new Events
                {
                    FightTitle = model.FightTitle,
                    FightVenue = model.FightVenue,
                    FightImage = uniqueFileName,
                    Fighters = model.Fighters,
                    FightPrice = model.FightPrice,
                    FightTime = model.FightTime,

                };
                _Fightcontext.Venues.Update(editEvents);
            }
            else
            {
                Events editEvents = new Events
                {
                    FightTitle = model.FightTitle,
                    FightVenue = model.FightVenue,
                    Fighters = model.Fighters,
                    FightPrice = model.FightPrice,
                    FightTime = model.FightTime,

                };
                _Fightcontext.Venues.Update(editEvents);
            }
            _Fightcontext.SaveChanges();
            return RedirectToAction("Index");

            //_context.Movies.Update(model);
            //_context.SaveChanges();
            //return RedirectToAction("Index");
        }

    

        [HttpGet]
        public IActionResult DeleteFilm(int Id)
        {
            Events model = _Fightcontext.Venues.Find(Id);
            return View(model);
        }

        [HttpPost]
        public IActionResult DeleteFilm(Events model)
        {
            _Fightcontext.Venues.Remove(model);
            _Fightcontext.SaveChanges();
            //return View(model);
            return RedirectToAction("Index");
        }

        [HttpGet]
        public IActionResult DeleteFighter(int Id)
        {
            Fighters model = _Fightcontext.Athletes.Find(Id);
            return View(model);
        }

        [HttpPost]
        public IActionResult DeleteFighter(Fighters model)
        {
            _Fightcontext.Athletes.Remove(model);
            _Fightcontext.SaveChanges();
            //return View(model);
            return RedirectToAction("Index");
        }

        [HttpGet]
        public IActionResult UpdateFighter(int id)
        {
            Fighters model = _Fightcontext.Athletes.Find(id);
            FighterForm formModel = new FighterForm
            {
                FirstName = model.FirstName,
                LastName = model.LastName,
                NickName = model.NickName,
                Height = model.Height,
                Weight = model.Weight,
                Reach = model.Reach,
                Stance = model.Stance,
                Wins = model.Wins,
                Loss = model.Loss,
                Draw = model.Draw,
                Belt = model.Belt,

            };
            
            return View(formModel);
        }

        [HttpPost]
        public IActionResult UpdateFighter(FighterForm model)
        {
        
                Fighters editFighters = new Fighters
                {
                    FirstName = model.FirstName,
                    LastName = model.LastName,
                    NickName = model.NickName,
                    Height = model.Height,
                    Weight = model.Weight,
                    Reach = model.Reach,
                    Stance = model.Stance,
                    Wins = model.Wins,
                    Loss = model.Loss,
                    Draw = model.Draw,
                    Belt = model.Belt,

                };
                _Fightcontext.Athletes.Update(editFighters);
            
            _Fightcontext.SaveChanges();
            return RedirectToAction("Index");

            //_context.Movies.Update(model);
            //_context.SaveChanges();
            //return RedirectToAction("Index");
        }

    }
}
