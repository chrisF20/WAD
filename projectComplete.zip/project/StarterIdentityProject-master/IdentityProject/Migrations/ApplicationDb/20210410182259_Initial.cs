﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace IdentityProject.Migrations.ApplicationDb
{
    public partial class Initial : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "AllCarsShow",
                columns: table => new
                {
                    CarID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Brand = table.Column<string>(type: "varchar(5)", nullable: false),
                    Model = table.Column<string>(type: "varchar(100)", nullable: false),
                    CarDescription = table.Column<string>(type: "text", nullable: true),
                    CarImage = table.Column<string>(type: "varchar(100)", nullable: true),
                    DayRate = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    Avaliability = table.Column<string>(type: "varchar(100)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AllCarsShow", x => x.CarID);
                });

            migrationBuilder.CreateTable(
                name: "Athletes",
                columns: table => new
                {
                    FighterID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FirstName = table.Column<string>(type: "varchar(100)", nullable: false),
                    LastName = table.Column<string>(type: "varchar(100)", nullable: false),
                    NickName = table.Column<string>(type: "varchar(100)", nullable: true),
                    Height = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    Weight = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    Reach = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    Stance = table.Column<string>(type: "text", nullable: true),
                    Wins = table.Column<int>(type: "Integer", nullable: false),
                    Loss = table.Column<int>(type: "Integer", nullable: false),
                    Draw = table.Column<int>(type: "Integer", nullable: false),
                    Belt = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Athletes", x => x.FighterID);
                });

            migrationBuilder.CreateTable(
                name: "CarOut",
                columns: table => new
                {
                    CarID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Brand = table.Column<string>(type: "varchar(5)", nullable: false),
                    Model = table.Column<string>(type: "varchar(100)", nullable: false),
                    CarDescription = table.Column<string>(type: "text", nullable: true),
                    ClientID = table.Column<string>(type: "varchar(100)", nullable: true),
                    Cost = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    LeaseDate = table.Column<DateTime>(nullable: false),
                    ReturnDate = table.Column<DateTime>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CarOut", x => x.CarID);
                });

            migrationBuilder.CreateTable(
                name: "Films",
                columns: table => new
                {
                    FilmID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FilmTitle = table.Column<string>(nullable: false),
                    FilmCertificate = table.Column<string>(nullable: false),
                    FilmDescription = table.Column<string>(nullable: true),
                    FilmImage = table.Column<string>(nullable: true),
                    FilmPrice = table.Column<decimal>(nullable: false),
                    Stars = table.Column<int>(nullable: false),
                    ReleaseDate = table.Column<DateTime>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Films", x => x.FilmID);
                });

            migrationBuilder.CreateTable(
                name: "Venues",
                columns: table => new
                {
                    FightID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FightTitle = table.Column<string>(type: "varchar(100)", nullable: false),
                    FightVenue = table.Column<string>(type: "text", nullable: true),
                    FightImage = table.Column<string>(type: "varchar(100)", nullable: true),
                    Fighters = table.Column<string>(type: "text", nullable: true),
                    FightPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    FightTime = table.Column<DateTime>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Venues", x => x.FightID);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "AllCarsShow");

            migrationBuilder.DropTable(
                name: "Athletes");

            migrationBuilder.DropTable(
                name: "CarOut");

            migrationBuilder.DropTable(
                name: "Films");

            migrationBuilder.DropTable(
                name: "Venues");
        }
    }
}
