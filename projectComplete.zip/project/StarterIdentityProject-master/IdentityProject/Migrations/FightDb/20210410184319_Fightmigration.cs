﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace IdentityProject.Migrations.FightDb
{
    public partial class Fightmigration : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Athletes",
                columns: table => new
                {
                    FighterID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FirstName = table.Column<string>(type: "varchar(100)", nullable: false),
                    LastName = table.Column<string>(type: "varchar(100)", nullable: false),
                    NickName = table.Column<string>(type: "varchar(100)", nullable: true),
                    Height = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    Weight = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    Reach = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    Stance = table.Column<string>(type: "text", nullable: true),
                    Wins = table.Column<int>(type: "Integer", nullable: false),
                    Loss = table.Column<int>(type: "Integer", nullable: false),
                    Draw = table.Column<int>(type: "Integer", nullable: false),
                    Belt = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Athletes", x => x.FighterID);
                });

            migrationBuilder.CreateTable(
                name: "Venues",
                columns: table => new
                {
                    FightID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FightTitle = table.Column<string>(type: "varchar(100)", nullable: false),
                    FightVenue = table.Column<string>(type: "text", nullable: true),
                    FightImage = table.Column<string>(type: "varchar(100)", nullable: true),
                    Fighters = table.Column<string>(type: "text", nullable: true),
                    FightPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    FightTime = table.Column<DateTime>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Venues", x => x.FightID);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Athletes");

            migrationBuilder.DropTable(
                name: "Venues");
        }
    }
}
