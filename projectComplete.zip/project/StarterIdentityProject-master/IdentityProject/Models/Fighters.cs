﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace IdentityProject.Models
{
    public class Fighters
    {
        [Key]
        public int FighterID { get; set; }

        [Required]
        [Column(TypeName = "varchar(100)")]
        public string FirstName { get; set; }

        [Required]
        [Column(TypeName = "varchar(100)")]
        public string LastName { get; set; }

        [Column(TypeName = "varchar(100)")]
        public string NickName { get; set; }

        [Column(TypeName = "decimal(18, 2)")]
        public decimal Height { get; set; }

        [Column(TypeName = "decimal(18, 2)")]
        public decimal Weight { get; set; }

        [Column(TypeName = "decimal(18, 2)")]
        public decimal Reach { get; set; }

        [Column(TypeName = "text")]
        public string Stance { get; set; }

        [Column(TypeName = "Integer")]
        public int Wins { get; set; }

        [Column(TypeName = "Integer")]
        public int Loss { get; set; }

        [Column(TypeName = "Integer")]
        public int Draw { get; set; }

        [Column(TypeName = "text")]
        public string Belt { get; set; }

    }
}
