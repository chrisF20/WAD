﻿using System;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Http;

namespace IdentityProject.Models
{
    public class FighterForm
    {
        [Key]
        public int FighterID { get; set; }

        [Required]
        public string FirstName { get; set; }

        [Required]
        public string LastName { get; set; }

        public string NickName { get; set; }

        public decimal Height { get; set; }

        public decimal Weight { get; set; }

        public decimal Reach { get; set; }

        public string Stance { get; set; }

        public int Wins { get; set; }

        public int Loss { get; set; }

        public int Draw { get; set; }

        public string Belt { get; set; }
    }
}
