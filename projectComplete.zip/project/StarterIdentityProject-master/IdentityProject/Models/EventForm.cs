﻿using System;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Http;

namespace IdentityProject.Models
{
    public class EventForm
    {
        [Key]
        public int FightID { get; set; }

        [Required]

        public string FightTitle { get; set; }

    
        public string FightVenue { get; set; }

       
        public IFormFile FightImage { get; set; }

     
        public string Fighters { get; set; }

       
        public decimal FightPrice { get; set; }

        [DataType(DataType.Date)]
        public DateTime FightTime { get; set; }
    }
}
